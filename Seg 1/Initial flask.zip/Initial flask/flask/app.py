from sqlalchemy import create_engine
from sqlalchemy import Table, Column, Integer, String, MetaData, ForeignKey
from sqlalchemy import inspect
import pandas as pd
from flask import Flask, render_template, redirect, url_for, jsonify
from sqlalchemy.sql import text
from flask import request
from sklearn.ensemble import RandomForestClassifier
import numpy as np
import json as json
import pickle

app = Flask(__name__)


@app.route("/")
def index():
   return render_template("index.html")


@app.route("/index.html", methods=['GET','POST'])
def reg_cust():
    if request.method == 'POST':
        
        age = request.form['age'] 
        gender = request.form['gender']
        income = request.form['income']
        taste = request.form['taste']
        price = request.form['price']
        calories = request.form['calories']
        total_spend = request.form['total_spend']

        customer_data = {
                "cust_gender": [int(1 if gender == "male" else 0)],
                "cust_age": [int(age)],
                "cust_q1_taste": [int(taste)],
                "cust_q2_price": [int(price)],
                "cust_q3_calories": [int(calories)],
                "cust_income_range": [int(income)],
                "total_spend": [float(total_spend)]}

    data_df = pd.DataFrame(customer_data)
    cols = ['cust_gender','cust_age', 'cust_q1_taste', 'cust_q2_price', 'cust_q3_calories', 'cust_income_range', 'total_spend']
    data_df = data_df[cols]
    
    with open('../models/reg_cust_sc.pkl', 'rb') as file:
        scaler = pickle.load(file)

    with open('../models/reg_cust_model.pkl', 'rb') as file:
        rfc = pickle.load(file)

    data_scaled = scaler.transform(data_df)
    prediction = rfc.predict(data_scaled)

    if prediction[0] == 1:
        model_result = "This customer is likely to become a regular one"
    else:
        model_result = 'Most probably the customer will not become a regular one'


    return render_template('result.html', model_result=model_result)        




if __name__ == "__main__":
    app.run()