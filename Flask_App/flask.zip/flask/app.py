from sqlalchemy import create_engine
from sqlalchemy import Table, Column, Integer, String, MetaData, ForeignKey
from sqlalchemy import inspect
import pandas as pd
from flask import Flask, render_template, redirect, url_for, jsonify
from sqlalchemy.sql import text
from flask import request
from sklearn.ensemble import RandomForestClassifier
import numpy as np
import json as json
import pickle

app = Flask(__name__)


@app.route("/")
def index():
   return render_template("index1.html")


@app.route("/result-rcp", methods=['GET','POST'])
def reg_cust():
    if request.method == 'POST':
        
        age = request.form['age'] 
        gender = request.form['gender']
        income = request.form['income']
        taste = request.form['taste']
        price = request.form['price']
        calories = request.form['calories']
        total_spend = request.form['total_spend']

        customer_data = {
                "cust_gender": [int(1 if gender == "male" else 0)],
                "cust_age": [int(age)],
                "cust_q1_taste": [int(taste)],
                "cust_q2_price": [int(price)],
                "cust_q3_calories": [int(calories)],
                "cust_income_range": [int(income)],
                "total_spend": [float(total_spend)]}

    data_df = pd.DataFrame(customer_data)
    cols = ['cust_gender','cust_age', 'cust_q1_taste', 'cust_q2_price', 'cust_q3_calories', 'cust_income_range', 'total_spend']
    data_df = data_df[cols]
    
    with open('../models/reg_cust/reg_cust_sc.pkl', 'rb') as file:
        scaler = pickle.load(file)

    with open('../models/reg_cust/reg_cust_model.pkl', 'rb') as file:
        rfc = pickle.load(file)

    data_scaled = scaler.transform(data_df)
    prediction = rfc.predict(data_scaled)

    if prediction[0] == 1:
        model_result = "This customer is likely to become a repeat customer"
    else:
        model_result = 'Most probably the customer will not become a repeat customer'

    return render_template('result_rcp.html', model_result=model_result)


@app.route("/result-order", methods=['GET','POST'])
def order():
    if request.method == 'POST':
        
        age = request.form['age'] 
        gender = request.form['gender']
        month = request.form['month']
        taste = request.form['taste']
        price = request.form['price']
        calories = request.form['calories']
        

        customer_data = {
                "cust_gender": [int(gender)],
                "cust_age": [int(age)],
                "cust_q1_taste": [int(taste)],
                "month": [int(month)],
                "calories_importance": [int(calories)],
                "price_importance": [int(price)]}
                

    data_df = pd.DataFrame(customer_data)
    cols = ['cust_gender','cust_age', 'cust_q1_taste', 'month', 'calories_importance', 'price_importance']
    data_df = data_df[cols]
    
    with open('../models/food/food_sc.pkl', 'rb') as file:
        food_scaler = pickle.load(file)

    with open('../models/food/food_model.pkl', 'rb') as file:
        food_model = pickle.load(file)

    with open('../models/drink/drink_sc.pkl', 'rb') as file:
        drink_scaler = pickle.load(file)

    with open('../models/drink/drink_model.pkl', 'rb') as file:
        drink_model = pickle.load(file)

    food_data_scaled = food_scaler.transform(data_df)
    food_prediction = food_model.predict(food_data_scaled)

    drink_data_scaled = drink_scaler.transform(data_df)
    drink_prediction = drink_model.predict(drink_data_scaled)

    food_group = food_prediction[0]
    drink_group = drink_prediction[0]

    food_class = pd.read_csv('../food_class.csv')
    food_opts = food_class[food_class['class'] == food_group].food_type.tolist()

    drink_class = pd.read_csv('../drink_class.csv')
    d_size = drink_class[drink_class['class'] == drink_group].drink_size.tolist()
    d_type = drink_class[drink_class['class'] == drink_group].drink_type.tolist()
    d_milk  = drink_class[drink_class['class'] == drink_group].drink_milk.tolist()
    drink_opts = list(zip(d_size, d_type, d_milk))

    order_opts = {'foods': food_opts, 'drinks': drink_opts}
    
    return render_template('result_order.html', order_opts=order_opts)    

# @app.route("/db-customer", methods=['GET','POST'])
# def db_customer():
#     if request.method == 'POST':
        
#         cust_id = request.form['cust_id']
#         age = request.form['age'] 
#         gender = request.form['gender']
#         income = request.form['income']
#         taste = request.form['taste']
#         price = request.form['price']
#         calories = request.form['calories']
        

#         customer_data = {
#                 "cust_id": int(cust_id),
#                 "age": int(age) if age else 'NULL',
#                 "gender": int(gender) if gender else 'NULL',
#                 "income": int(income) if income else 'NULL',
#                 "taste": int(taste) if taste else 'NULL',
#                 "price": int(price) if price else 'NULL',
#                 "calories": int(calories) if calories else 'NULL'}

#         engine = create_engine('postgresql+psycopg2://postgres:Ehsan$2694@localhost/cafe_db')
#         query = f"INSERT INTO new_customer_info(cust_id, cust_gender, cust_age, cust_income, cust_q1_taste, cust_q2_price, cust_q3_calories)\nvalues ({customer_data['cust_id']}, {customer_data['gender']},{customer_data['age']}, {customer_data['income']}, {customer_data['taste']}, {customer_data['price']}, {customer_data['calories']});"
#         engine.execute(query)
            

#     return customer_data



if __name__ == "__main__":
    app.run()